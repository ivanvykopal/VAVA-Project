/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit.Controllers;

/**
 * Interface určený pre možnosť vkladať metódy ako parametre metód.
 *
 * @author Ivan Vykopal
 */
public interface IMethod {

    
    void method();
}
